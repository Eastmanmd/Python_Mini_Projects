from . import data

pokemon_data = data.get_data()

def get_pokemon_info(pokemon_name):
    #returns a list of containing the information for a given pokemon 
    for pokemon in pokemon_data:
        if pokemon["name"] == pokemon_name:
            pokemon_info = pokemon
    return pokemon_info   

def attack_diff(pokemon_1, pokemon_2):
    difference = float(get_pokemon_info(pokemon_1)["attack"]) - float(get_pokemon_info(pokemon_2)["attack"])
    return difference 

def defense_diff(pokemon_1, pokemon_2):
    difference = float(get_pokemon_info(pokemon_1)["defense"]) - float(get_pokemon_info(pokemon_2)["defense"])
    return difference 
    
def hp_diff(pokemon_1, pokemon_2):
    difference = float(get_pokemon_info(pokemon_1)["hp"]) - float(get_pokemon_info(pokemon_2)["hp"])
    return difference

def combat_power(pokemon_name):
    #return the combat power for a given pokemon
    Attack = 2 * round((((float(get_pokemon_info(pokemon_name)["attack"]))** 0.5) * ((float(get_pokemon_info(pokemon_name)["sp_attack"]))** 0.5) +((float(get_pokemon_info(pokemon_name)["speed"]))** 0.5)))
    Defense = 2 * round((((float(get_pokemon_info(pokemon_name)["defense"]))** 0.5) * ((float(get_pokemon_info(pokemon_name)["sp_defense"]))** 0.5) + ((float(get_pokemon_info(pokemon_name)["speed"]))** 0.5)))
    Stamina = 2 * (float(get_pokemon_info(pokemon_name)["hp"]))
    MaxCP = (Attack + 15) * ((Defense + 15)**0.5) * ((Stamina + 15)**0.5) * (0.7903001** 2 / 10)
    return MaxCP
    
def combat_power_diff(pokemon_1, pokemon_2):
    difference = float(combat_power(pokemon_1)) - float(combat_power(pokemon_2))
    return difference 