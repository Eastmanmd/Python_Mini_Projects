from . import data

pokemon_data = data.get_data()

def generation_types(generation_number):
    type_count = {}
    for pokemon in pokemon_data:
        if pokemon["generation"] == generation_number:
            if pokemon["primary_type"] in type_count:
                type_count[pokemon["primary_type"]]+= 1
            else:
                type_count[pokemon["primary_type"]] = 1
    return type_count


def generation_ranges(generation_number):
    generation_range = []
    
    min_hp = min([pokemon["hp"] for pokemon in pokemon_data if pokemon["generation"] == generation_number])
    max_hp = max([pokemon["hp"] for pokemon in pokemon_data if pokemon["generation"] == generation_number])
            
    min_attack = min([pokemon["attack"] for pokemon in pokemon_data if pokemon["generation"] == generation_number])
    max_attack = max([pokemon["attack"] for pokemon in pokemon_data if pokemon["generation"] == generation_number])
            
    min_defense = min([pokemon["defense"] for pokemon in pokemon_data if pokemon["generation"] == generation_number])
    max_defense = max([pokemon["defense"] for pokemon in pokemon_data if pokemon["generation"] == generation_number])
            
    generation_range.append((min_hp, max_hp))
    generation_range.append((min_attack, max_attack))
    generation_range.append((min_defense, max_defense))
    
    pokemon_dict = dict(zip(["hp", "attack", "defense"], generation_range))
    
    return pokemon_dict


    