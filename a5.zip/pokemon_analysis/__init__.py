""" Name: Ali Eastman Oku
    ZID: Z-1893417
    Assignment 5
"""

from . import data
from . import compare
from . import generation