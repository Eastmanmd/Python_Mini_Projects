import json

import os
fname = os.path.join(os.path.dirname(__file__),'pokemon.json')

pokemon_data = -1

def get_data():
    global pokemon_data
    if pokemon_data == -1:
        pokemon_data = json.load(open(fname))
        return pokemon_data
        
    else:
        return pokemon_data

