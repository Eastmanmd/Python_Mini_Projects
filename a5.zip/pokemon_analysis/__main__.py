""" Name: Ali Eastman Oku
    ZID: Z-1893417
    Assignment 5
"""

import sys
from .generation import generation_ranges
from .generation import generation_types
from .compare import get_pokemon_info
from .compare import combat_power
from .compare import combat_power_diff
from .compare import attack_diff
from .compare import defense_diff
from .compare import hp_diff



def usage_error():
    
    error = "Usage: python -m pokemon_analysis [generation <num> | compare <name1> <name2> | gen_types <num> | attack_diff <name1> <name2> | hp_diff <name1> <name2> | defense_diff <name1> <name2> ]"
    
    if len(sys.argv) < 2:
        print(error)
        sys.exit(0)
    
    if sys.argv[1] == "generation" and len(sys.argv) != 3: 
        print(error)
        sys.exit(0)
    
    if sys.argv[1] == "compare" and len(sys.argv) < 4:
        print (error)
        
    if sys.argv[1] == "gen_types" and len(sys.argv) != 3:
        print(error)
        
    if sys.argv[1] == "attack_diff" and len(sys.argv) < 4:
        print (error)
        
    if sys.argv[1] == "hp_diff" and len(sys.argv) < 4:
        print (error)

    if sys.argv[1] == "defense_diff" and len(sys.argv) < 4:
        print (error)
        
usage_error()

if sys.argv[1] == "generation" and len(sys.argv) == 3:
    for k,v in generation_ranges(int(sys.argv[2])).items():
        range_format = str(k) + ": " + str(list(v)[0]) + "-" + str(list(v)[1])
        print(range_format)
        
if sys.argv[1] == "compare" and len(sys.argv) == 4:
    combat_diff = str(round(combat_power_diff(sys.argv[2], sys.argv[3]), 6))
    if combat_diff[0] != "-":
        combat_diff = "+" + combat_diff
    
    combat_diff_output = sys.argv[2] + " has " + combat_diff + " combat power than " + sys.argv[3]
    print(combat_diff_output)
    
if sys.argv[1] == "compare" and len(sys.argv) > 4:
    for i in range(2, len(sys.argv)):
        for j in range(i+1, len(sys.argv)):
            combat_diff = str(round(combat_power_diff(sys.argv[i], sys.argv[j]), 6))
            combat_diff2 = str(round(combat_power_diff(sys.argv[j], sys.argv[i]), 6))
            
            if combat_diff[0] != "-":
                combat_diff = "+" + combat_diff
                
            if combat_diff2[0] != "-":
                combat_diff = "+" + combat_diff2         
    
            combat_diff_output = sys.argv[i] + " has " + combat_diff + " combat power than " + sys.argv[j]
            combat_diff_output2 = sys.argv[j] + " has " + combat_diff2 + " combat power than " + sys.argv[i]
            print(combat_diff_output)    
            print(combat_diff_output2)

if sys.argv[1] == "gen_types" and len(sys.argv) == 3:
    gen_type = generation_types(int(sys.argv[2]))
    for k,v in gen_type.items():
        print("Type:", k, "| Count:", v)
        

if sys.argv[1] == "attack_diff" and len(sys.argv) == 4:
    attack_diff = str(attack_diff(sys.argv[2], sys.argv[3]))
    if attack_diff[0] != "-":
        attack_diff = "+" + attack_diff 
        
    attack_diff_output = sys.argv[2] + " has " + attack_diff + " attack value than " + sys.argv[3]
    print(attack_diff_output)
    

if sys.argv[1] == "defense_diff" and len(sys.argv) == 4:
    defense_diff = str(defense_diff(sys.argv[2], sys.argv[3]))
    if defense_diff[0] != "-":
        defense_diff = "+" + defense_diff 
        
    defense_diff_output = sys.argv[2] + " has " + defense_diff + " defense value than " + sys.argv[3]
    print(defense_diff_output)       


if sys.argv[1] == "hp_diff" and len(sys.argv) == 4:
    hp_diff = str(hp_diff(sys.argv[2], sys.argv[3]))
    if hp_diff[0] != "-":
        hp_diff = "+" + hp_diff 
        
    hp_diff_output = sys.argv[2] + " has " + hp_diff + " hp than " + sys.argv[3]
    print(hp_diff_output)